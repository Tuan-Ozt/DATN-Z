﻿public enum ArmorPart
{
    Armor = 0,       // Áo
    Boots = 1,       // Quần / giày
    Gloves = 2,      // Bao tay
    Pauldrons = 3,   // Giáp vai
    Vest = 4,        // Áo trong
    Belt = 5         // Thắt lưng
}
