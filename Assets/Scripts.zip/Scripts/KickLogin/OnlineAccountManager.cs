﻿using Fusion;
using System.Collections.Generic;

public static class OnlineAccountManager
{
    public static Dictionary<string, PlayerRef> OnlineTokens = new Dictionary<string, PlayerRef>();
}
