﻿[System.Serializable]
public class CharacterDataUI
{
    public int strength;
    public int defense;
    public int agility;
    public int vitality;
}
//dữ liệu chỉ số player 